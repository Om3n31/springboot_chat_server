package com.example.demo

import com.example.demo.model.UserBean
import com.j256.ormlite.dao.Dao
import com.j256.ormlite.dao.DaoManager
import com.j256.ormlite.jdbc.JdbcConnectionSource

class UserDao {
    companion object {
        //Typage du Dao <Bean, typage Id>
        private fun getDao(jdbc: JdbcConnectionSource): Dao<UserBean, Long> =
                DaoManager.createDao(jdbc, UserBean::class.java)

        //Méthode pour sauvegarder un user
        fun saveUser(data: UserBean, jdbc: JdbcConnectionSource) = getDao(jdbc).createOrUpdate(data)

        //Méthode pour trouver un user en fonction de son pseudo
        fun getUserByPseudo(name: String, jdbc: JdbcConnectionSource) =
                getDao(jdbc).queryBuilder().where().eq("user_pseudo", name).query()


        //Méthode pour charger tous les user en Arraylist
        fun loadUsers(jdbc: JdbcConnectionSource) = ArrayList(getDao(jdbc).queryForAll())
    }
}