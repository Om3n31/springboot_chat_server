package com.example.demo

import com.example.demo.model.ErrorBean
import com.example.demo.model.MessageBean
import com.example.demo.model.UserBean
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RestController


//Permet de transformer une class en WebService
@RestController
class MyControler {


    //METHODE : RENVOIE UNE STRING AU WEB SERVICE
    //http://localhost:8080/test
    @GetMapping("/test")
    fun testMethode(): MessageBean {
        println("/test")
        var message = MessageBean(1, "test", 19, UserBean(1, "Thomas"))
        return message
    }

    @GetMapping("/messageGet")
    fun messageGet(): Any {
        println("/messageGet")

        val conn = DaoConnexion()
        try {
            return MessageDao.loadMessages(conn.connectionSource)
        } catch (e: Exception) {
            e.printStackTrace()
            return ErrorBean(e.message ?: "Une erreur est survenue")
        } finally {
            //Déconnexion du Dao
            conn.closeConnexion()
        }
        

    }


    @PostMapping("/messagePost")
    fun messagePost(@RequestBody messageBean: MessageBean): ErrorBean? {
        println("/messagePost")
        val conn = DaoConnexion()
        try {
            //Sauvegarder le message
            MessageDao.saveMessage(messageBean, conn.connectionSource)
            return null
        } catch (e: Exception) {
            e.printStackTrace()
            return ErrorBean(e.message ?: "Une erreur est survenue")
        } finally {
            //Déconnexion du Dao
            conn.closeConnexion()
        }
    }


}