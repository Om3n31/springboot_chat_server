package com.example.demo.model

data class ErrorBean(var errorMessage: String)