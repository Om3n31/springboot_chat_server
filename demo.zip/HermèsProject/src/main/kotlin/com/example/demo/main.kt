package com.example.demo

import com.example.demo.model.MessageBean
import com.example.demo.model.UserBean

fun main() {
    val message = MessageBean(null, "Bonjour", 12, UserBean(null, "André", 15))
    val conn = DaoConnexion()

    //Sauvegarder le message
    MessageDao.saveMessage(MessageBean(null, "test", 9, UserBean(null, "toto", 10)), conn.connectionSource)

    var arrayMessage = MessageDao.loadMessages(conn.connectionSource)

    //Déconnexion du Dao
    conn.closeConnexion()

    arrayMessage.forEach { println(it) }
}