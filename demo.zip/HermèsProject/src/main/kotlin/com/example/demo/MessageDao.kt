package com.example.demo

import com.example.demo.model.MessageBean
import com.j256.ormlite.dao.Dao
import com.j256.ormlite.dao.DaoManager
import com.j256.ormlite.jdbc.JdbcConnectionSource

class MessageDao {
    companion object {
        //Typage du Dao <Bean, typage Id>
        private fun getDao(jdbc: JdbcConnectionSource): Dao<MessageBean, Long> =
                DaoManager.createDao(jdbc, MessageBean::class.java)

        //Méthode pour sauvegarder un message
        fun saveMessage(data: MessageBean, jdbc: JdbcConnectionSource) {
            UserDao.saveUser(data.user, jdbc)
            getDao(jdbc).createOrUpdate(data)
        }

//        getDao(jdbc).queryBuilder().where().eq("user_pseudo", name).query()

        //Méthode pour charger tous les message en Arraylist
        fun loadMessages(jdbc: JdbcConnectionSource) = ArrayList(getDao(jdbc).queryBuilder().limit(20).query())
    }
}