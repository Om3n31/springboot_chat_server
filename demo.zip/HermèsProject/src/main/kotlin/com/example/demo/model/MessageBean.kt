package com.example.demo.model

import com.j256.ormlite.field.DatabaseField
import com.j256.ormlite.table.DatabaseTable

@DatabaseTable(tableName = "messages")
data class MessageBean(

        @DatabaseField(generatedId = true)
        var id_message: Long? = null,

        @DatabaseField
        var message: String,

        @DatabaseField
        var post_date: Long?,

        @DatabaseField(foreignAutoRefresh = true, foreign = true)
        var user: UserBean) {

    constructor(message: String) : this(null, message, 0, UserBean())
    constructor() : this(null, "", 0, UserBean())

}