package com.example.demo

object Constante {
    const val URL = "jdbc:mysql://localhost:3306/hermès?serverTimezone=UTC"
    const val LOGIN = "root"
    const val PASSWORD = "root"
}